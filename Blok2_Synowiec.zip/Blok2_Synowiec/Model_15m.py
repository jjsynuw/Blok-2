"""
Model exported as python.
Name : analiza_dostepnosci_15m
Group : miasto15m
With QGIS : 34015
"""

from qgis.core import QgsProcessing
from qgis.core import QgsProcessingAlgorithm
from qgis.core import QgsProcessingMultiStepFeedback
from qgis.core import QgsProcessingParameterVectorLayer
from qgis.core import QgsProcessingParameterNumber
from qgis.core import QgsProcessingParameterFeatureSink
import processing


class Analiza_dostepnosci_15m(QgsProcessingAlgorithm):

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer('granice_miasta', 'Granice miasta', types=[QgsProcessing.TypeVectorPolygon], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_edukacja', 'POI Edukacja', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_handel', 'POI Handel', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_transport', 'POI Transport', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_zdrowie', 'POI Zdrowie', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterVectorLayer('poi_ziele', 'POI Ziele�', types=[QgsProcessing.TypeVectorPoint], defaultValue=None))
        self.addParameter(QgsProcessingParameterNumber('waga_edukacji', 'Waga edukacji', type=QgsProcessingParameterNumber.Double, defaultValue=3))
        self.addParameter(QgsProcessingParameterNumber('waga_transportu', 'Waga transportu', type=QgsProcessingParameterNumber.Double, defaultValue=1))
        self.addParameter(QgsProcessingParameterNumber('waga_zdrowia', 'Waga zdrowia', type=QgsProcessingParameterNumber.Double, defaultValue=3))
        self.addParameter(QgsProcessingParameterNumber('waga_handlu', 'Waga handlu', type=QgsProcessingParameterNumber.Double, defaultValue=2))
        self.addParameter(QgsProcessingParameterNumber('waga_zieleni', 'Waga zieleni', type=QgsProcessingParameterNumber.Double, defaultValue=2))
        self.addParameter(QgsProcessingParameterFeatureSink('Siatka_analiza_15m', 'siatka_analiza_15m', optional=True, type=QgsProcessing.TypeVectorAnyGeometry, createByDefault=True, defaultValue=None))

    def processAlgorithm(self, parameters, context, model_feedback):
        # Use a multi-step feedback, so that individual child algorithm progress reports are adjusted for the
        # overall progress through the model
        feedback = QgsProcessingMultiStepFeedback(12, model_feedback)
        results = {}
        outputs = {}

        # Utw�rz siatk�
        alg_params = {
            'CRS': 'ProjectCrs',
            'EXTENT': parameters['granice_miasta'],
            'HOVERLAY': 0,
            'HSPACING': 250,
            'TYPE': 4,  # Sze�ciok�t (poligon)
            'VOVERLAY': 0,
            'VSPACING': 250,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['UtwrzSiatk'] = processing.run('native:creategrid', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(1)
        if feedback.isCanceled():
            return {}

        # Przytnij
        alg_params = {
            'INPUT': outputs['UtwrzSiatk']['OUTPUT'],
            'OVERLAY': parameters['granice_miasta'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Przytnij'] = processing.run('native:clip', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(2)
        if feedback.isCanceled():
            return {}

        # Centroidy
        alg_params = {
            'ALL_PARTS': False,
            'INPUT': outputs['Przytnij']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Centroidy'] = processing.run('native:centroids', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(3)
        if feedback.isCanceled():
            return {}

        # Otoczka
        alg_params = {
            'DISSOLVE': False,
            'DISTANCE': 1000,
            'END_CAP_STYLE': 0,  # zaokr�glony
            'INPUT': outputs['Centroidy']['OUTPUT'],
            'JOIN_STYLE': 0,  # zaokr�glony
            'MITER_LIMIT': 2,
            'SEGMENTS': 5000,
            'SEPARATE_DISJOINT': False,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['Otoczka'] = processing.run('native:buffer', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(4)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie edukacja
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_edukacja',
            'POINTS': parameters['poi_edukacja'],
            'POLYGONS': outputs['Otoczka']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PoliczPunktyWPoligonieEdukacja'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(5)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie handel
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_handel',
            'POINTS': parameters['poi_handel'],
            'POLYGONS': outputs['PoliczPunktyWPoligonieEdukacja']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PoliczPunktyWPoligonieHandel'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(6)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie transport
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_transport',
            'POINTS': parameters['poi_transport'],
            'POLYGONS': outputs['PoliczPunktyWPoligonieHandel']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PoliczPunktyWPoligonieTransport'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(7)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie zdrowie
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_zdrowie',
            'POINTS': parameters['poi_zdrowie'],
            'POLYGONS': outputs['PoliczPunktyWPoligonieTransport']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PoliczPunktyWPoligonieZdrowie'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(8)
        if feedback.isCanceled():
            return {}

        # Policz punkty w poligonie zielen
        alg_params = {
            'CLASSFIELD': None,
            'FIELD': 'cnt_zielen',
            'POINTS': parameters['poi_ziele'],
            'POLYGONS': outputs['PoliczPunktyWPoligonieZdrowie']['OUTPUT'],
            'WEIGHT': None,
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['PoliczPunktyWPoligonieZielen'] = processing.run('native:countpointsinpolygon', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(9)
        if feedback.isCanceled():
            return {}

        # Kalkulator p�l
        alg_params = {
            'FIELD_LENGTH': 4,
            'FIELD_NAME': 'indeks_15m',
            'FIELD_PRECISION': 1,
            'FIELD_TYPE': 0,  # Liczba dziesi�tna (double)
            'FORMULA': '(\r\n  (IF("cnt_edukacja" > 0, 1, 0) * @waga_edukacji) +\r\n  (IF("cnt_zdrowie" > 0, 1, 0) * @waga_zdrowia) +\r\n  (IF("cnt_handel" > 0, 1, 0) * @waga_handlu) +\r\n  (IF("cnt_zielen" > 0, 1, 0) * @waga_zieleni) +\r\n  (IF("cnt_transport" > 0, 1, 0) * @waga_transportu)\r\n) / (@waga_edukacji + @waga_zdrowia + @waga_handlu + @waga_zieleni + @waga_transportu) * 100.0',
            'INPUT': outputs['PoliczPunktyWPoligonieZielen']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPl'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(10)
        if feedback.isCanceled():
            return {}

        # Kalkulator p�l dodatkowe
        alg_params = {
            'FIELD_LENGTH': 4,
            'FIELD_NAME': 'index_15m_bonus',
            'FIELD_PRECISION': 1,
            'FIELD_TYPE': 0,  # Liczba dziesi�tna (double)
            'FORMULA': '(\r\n  ((min("cnt_edukacja", 3) / 3.0) * @waga_edukacji) +\r\n  ((min("cnt_zdrowie", 5) / 5.0) * @waga_zdrowia) +\r\n  ((min("cnt_handel", 8) / 8.0) * @waga_handlu) +\r\n  ((min("cnt_zielen", 12) / 12.0) * @waga_zieleni) +\r\n  ((min("cnt_transport", 12) / 12.0) * @waga_transportu)\r\n) / (@waga_edukacji + @waga_zdrowia + @waga_handlu + @waga_zieleni + @waga_transportu) * 100.0',
            'INPUT': outputs['KalkulatorPl']['OUTPUT'],
            'OUTPUT': QgsProcessing.TEMPORARY_OUTPUT
        }
        outputs['KalkulatorPlDodatkowe'] = processing.run('native:fieldcalculator', alg_params, context=context, feedback=feedback, is_child_algorithm=True)

        feedback.setCurrentStep(11)
        if feedback.isCanceled():
            return {}

        # Z��cz atrybuty wed�ug warto�ci pola
        alg_params = {
            'DISCARD_NONMATCHING': False,
            'FIELD': 'id',
            'FIELDS_TO_COPY': [''],
            'FIELD_2': 'id',
            'INPUT': outputs['Przytnij']['OUTPUT'],
            'INPUT_2': outputs['KalkulatorPlDodatkowe']['OUTPUT'],
            'METHOD': 1,  # przyjmuj atrybuty tylko z pierwszego pasuj�cego obiektu (jeden do jednego)
            'PREFIX': None,
            'OUTPUT': parameters['Siatka_analiza_15m']
        }
        outputs['ZczAtrybutyWedugWartociPola'] = processing.run('native:joinattributestable', alg_params, context=context, feedback=feedback, is_child_algorithm=True)
        results['Siatka_analiza_15m'] = outputs['ZczAtrybutyWedugWartociPola']['OUTPUT']
        return results

    def name(self):
        return 'analiza_dostepnosci_15m'

    def displayName(self):
        return 'analiza_dostepnosci_15m'

    def group(self):
        return 'miasto15m'

    def groupId(self):
        return 'miasto15m'

    def createInstance(self):
        return Analiza_dostepnosci_15m()
